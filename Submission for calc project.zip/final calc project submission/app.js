const canvas = document.querySelector("#plot");
const ctx = canvas.getContext("2d");

const controls = {
  functionInput: document.querySelector("#functionInput"),
  viewMode: document.querySelector("#viewMode"),
  derivativeMode: document.querySelector("#derivativeMode"),
  integralMode: document.querySelector("#integralMode"),
  functionColor: document.querySelector("#functionColor"),
  tangentColor: document.querySelector("#tangentColor"),
  areaColor: document.querySelector("#areaColor"),
  zoomRange: document.querySelector("#zoomRange"),
  zoomIn: document.querySelector("#zoomIn"),
  zoomOut: document.querySelector("#zoomOut"),
  zoomReset: document.querySelector("#zoomReset"),
  boundA: document.querySelector("#boundA"),
  boundB: document.querySelector("#boundB"),
  boundANumber: document.querySelector("#boundANumber"),
  boundBNumber: document.querySelector("#boundBNumber"),
  resetBounds: document.querySelector("#resetBounds"),
  pointX: document.querySelector("#pointX"),
  pointXNumber: document.querySelector("#pointXNumber"),
  rectangles: document.querySelector("#rectangles"),
};

const tabs = [...document.querySelectorAll(".tab")];
const modePanels = [...document.querySelectorAll(".mode-panel")];
const derivativeFields = [...document.querySelectorAll(".derivative-field")];
const integralFields = [...document.querySelectorAll(".integral-field")];

const outputs = {
  readout: document.querySelector("#readout"),
  zoomValue: document.querySelector("#zoomValue"),
  boundAValue: document.querySelector("#boundAValue"),
  boundBValue: document.querySelector("#boundBValue"),
  pointValue: document.querySelector("#pointValue"),
  rectOutput: document.querySelector("#rectOutput"),
  fxValue: document.querySelector("#fxValue"),
  slopeValue: document.querySelector("#slopeValue"),
  areaValue: document.querySelector("#areaValue"),
  errorText: document.querySelector("#errorText"),
};

const state = {
  xMin: -5,
  xMax: 5,
  yMin: -4,
  yMax: 4,
  viewCenter: 0,
  viewHalfWidth: 7,
  lastBoundsKey: "",
  fn: (x) => Math.sin(x),
  expression: "sin(x)",
  valid: true,
  isPanning: false,
  panStartX: 0,
  panStartY: 0,
  panStartCenter: 0,
  panStartYCenter: 0,
  manualYView: false,
};

const GRAPH_MIN = -100;
const GRAPH_MAX = 100;

const safeNames = new Set([
  "x",
  "sin",
  "cos",
  "tan",
  "asin",
  "acos",
  "atan",
  "sqrt",
  "abs",
  "exp",
  "log",
  "ln",
  "pow",
  "min",
  "max",
  "floor",
  "ceil",
  "round",
  "sign",
  "sec",
  "csc",
  "cot",
  "pi",
  "e",
]);

function compileFunction(expression) {
  const normalized = expression.trim().replaceAll("^", "**");
  if (!normalized) throw new Error("Type a function first.");
  if (/[^0-9a-zA-Z_+\-*/().,\s]/.test(normalized)) {
    throw new Error("Only math symbols, numbers, and function names are allowed.");
  }

  const names = normalized.match(/[a-zA-Z_][a-zA-Z0-9_]*/g) || [];
  const unknown = names.find((name) => !safeNames.has(name));
  if (unknown) throw new Error(`Unknown symbol: ${unknown}`);

  const body = `
    const sin = Math.sin, cos = Math.cos, tan = Math.tan;
    const asin = Math.asin, acos = Math.acos, atan = Math.atan;
    const sqrt = Math.sqrt, abs = Math.abs, exp = Math.exp, log = Math.log, ln = Math.log;
    const pow = Math.pow, min = Math.min, max = Math.max;
    const floor = Math.floor, ceil = Math.ceil, round = Math.round, sign = Math.sign;
    const sec = (v) => 1 / Math.cos(v), csc = (v) => 1 / Math.sin(v), cot = (v) => 1 / Math.tan(v);
    const pi = Math.PI, e = Math.E;
    return (${normalized});
  `;
  const fn = new Function("x", body);
  const hasNumericSample = [-1, 0, 1, 2].some((x) => {
    const value = fn(x);
    return typeof value === "number" && !Number.isNaN(value);
  });
  if (!hasNumericSample) {
    throw new Error("The function did not return a usable number.");
  }
  return { fn, normalized };
}

function activeFn(x) {
  return state.fn(x);
}

function derivativeAt(x) {
  const h = 0.00001;
  return (activeFn(x + h) - activeFn(x - h)) / (2 * h);
}

function sumValue(method, a, b, n) {
  const dx = (b - a) / n;
  let total = 0;
  for (let i = 0; i < n; i += 1) {
    const left = a + i * dx;
    const right = left + dx;
    if (method === "right") total += activeFn(right) * dx;
    else if (method === "trapezoid") total += ((activeFn(left) + activeFn(right)) / 2) * dx;
    else total += activeFn(left) * dx;
  }
  return total;
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.round(rect.width * ratio);
  canvas.height = Math.round(rect.height * ratio);
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  draw();
}

function plotWidth() {
  return canvas.getBoundingClientRect().width;
}

function plotHeight() {
  return canvas.getBoundingClientRect().height;
}

function toPxX(x) {
  return ((x - state.xMin) / (state.xMax - state.xMin)) * plotWidth();
}

function toPxY(y) {
  return plotHeight() - ((y - state.yMin) / (state.yMax - state.yMin)) * plotHeight();
}

function toMathX(px) {
  return state.xMin + (px / plotWidth()) * (state.xMax - state.xMin);
}

function toMathY(py) {
  return state.yMax - (py / plotHeight()) * (state.yMax - state.yMin);
}

function updateFunction() {
  try {
    const compiled = compileFunction(controls.functionInput.value);
    state.fn = compiled.fn;
    state.expression = compiled.normalized;
    state.valid = true;
    outputs.errorText.textContent = "";
  } catch (error) {
    state.valid = false;
    outputs.errorText.textContent = error.message;
  }
}

function syncFromInputs() {
  let a = Number(controls.boundA.value);
  let b = Number(controls.boundB.value);
  const currentX0 = Number(controls.pointX.value);

  if (a > b) {
    [a, b] = [b, a];
    controls.boundA.value = String(a);
    controls.boundB.value = String(b);
  }
  controls.pointX.min = String(a);
  controls.pointX.max = String(b);
  controls.pointX.value = String(clamp(currentX0, a, b));
  controls.pointXNumber.min = String(a);
  controls.pointXNumber.max = String(b);
  controls.pointXNumber.value = Number(controls.pointX.value).toFixed(2);

  const boundsKey = `${a}:${b}`;
  if (boundsKey !== state.lastBoundsKey) {
    state.lastBoundsKey = boundsKey;
    resetViewToBounds(a, b);
  }

  state.xMin = state.viewCenter - state.viewHalfWidth;
  state.xMax = state.viewCenter + state.viewHalfWidth;
  if (!state.manualYView) {
    [state.yMin, state.yMax] = sampleYRange(state.xMin, state.xMax);
  }
}

function sampleYRange(a, b) {
  const values = [0];
  for (let i = 0; i <= 900; i += 1) {
    const x = a + ((b - a) * i) / 900;
    const y = activeFn(x);
    if (Number.isFinite(y) && Math.abs(y) < 100000) values.push(y);
  }
  if (values.length < 2) return [-4, 4];
  const low = Math.min(...values);
  const high = Math.max(...values);
  const padding = Math.max((high - low) * 0.16, 1);
  return [low - padding, high + padding];
}

function draw() {
  updateFunction();
  if (!state.valid) return;
  syncFromInputs();

  const w = plotWidth();
  const h = plotHeight();
  const { a, b } = getBounds();
  const x0 = Number(controls.pointX.value);
  const n = Number(controls.rectangles.value);
  const viewMode = controls.viewMode.value;

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#fbfbfb";
  ctx.fillRect(0, 0, w, h);

  drawGrid();
  if (viewMode !== "derivative") drawIntegral(a, b, n);
  drawCurve(activeFn, controls.functionColor.value, 3);
  if (viewMode !== "integral") drawDerivative(x0);
  drawBounds(a, b);
  drawLabels();
  updateReadouts();
}

function drawGrid() {
  const w = plotWidth();
  const h = plotHeight();
  const xStep = chooseStep(state.xMax - state.xMin);
  const yStep = chooseStep(state.yMax - state.yMin);
  const axisX = clamp(toPxX(0), 0, w);
  const axisY = clamp(toPxY(0), 0, h);

  ctx.lineWidth = 1;
  ctx.strokeStyle = "#e5e8ec";
  ctx.beginPath();
  for (let x = Math.ceil(state.xMin / xStep) * xStep; x <= state.xMax; x += xStep) {
    ctx.moveTo(toPxX(x), 0);
    ctx.lineTo(toPxX(x), h);
  }
  for (let y = Math.ceil(state.yMin / yStep) * yStep; y <= state.yMax; y += yStep) {
    ctx.moveTo(0, toPxY(y));
    ctx.lineTo(w, toPxY(y));
  }
  ctx.stroke();

  ctx.strokeStyle = "#252a31";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(0, toPxY(0));
  ctx.lineTo(w, toPxY(0));
  ctx.moveTo(toPxX(0), 0);
  ctx.lineTo(toPxX(0), h);
  ctx.stroke();

  ctx.fillStyle = "#6b7280";
  ctx.font = "12px Inter, system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  for (let x = Math.ceil(state.xMin / xStep) * xStep; x <= state.xMax; x += xStep) {
    if (Math.abs(x) < 1e-9) continue;
    const px = toPxX(x);
    if (px < 18 || px > w - 18) continue;
    ctx.fillText(formatTick(x), px, Math.min(axisY + 6, h - 18));
  }

  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  for (let y = Math.ceil(state.yMin / yStep) * yStep; y <= state.yMax; y += yStep) {
    if (Math.abs(y) < 1e-9) continue;
    const py = toPxY(y);
    if (py < 16 || py > h - 16) continue;
    ctx.fillText(formatTick(y), Math.max(axisX - 7, 24), py);
  }

  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText("0", Math.min(axisX + 7, w - 18), Math.min(axisY + 6, h - 18));
}

function chooseStep(span) {
  const targetTicks = 8;
  const rough = span / targetTicks;
  const power = 10 ** Math.floor(Math.log10(Math.max(rough, 0.001)));
  const scaled = rough / power;
  const nice = scaled <= 1 ? 1 : scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;
  return nice * power;
}

function drawCurve(fn, color, width, dash = []) {
  const w = plotWidth();
  const h = plotHeight();
  let started = false;
  let previousPy = 0;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.setLineDash(dash);
  ctx.beginPath();
  for (let px = 0; px <= w; px += 2) {
    const x = toMathX(px);
    const y = fn(x);
    if (!Number.isFinite(y) || Math.abs(y) > 100000) {
      started = false;
      continue;
    }
    const py = toPxY(y);
    if (started && Math.abs(py - previousPy) > h * 1.4) {
      started = false;
    }
    if (!started) {
      ctx.moveTo(px, py);
      started = true;
    } else {
      ctx.lineTo(px, py);
    }
    previousPy = py;
  }
  ctx.stroke();
  ctx.restore();
}

function drawDerivative(x0) {
  const mode = activeDerivativeMode();
  if (mode === "curve" || mode === "both") {
    drawCurve(derivativeAt, "#3e63dd", 2, [8, 7]);
  }
  if (mode === "tangent" || mode === "both") {
    drawTangent(x0);
  }
}

function drawTangent(x0) {
  const y0 = activeFn(x0);
  const slope = derivativeAt(x0);
  const span = (state.xMax - state.xMin) * 0.12;
  const x1 = x0 - span;
  const x2 = x0 + span;
  const y1 = y0 + slope * (x1 - x0);
  const y2 = y0 + slope * (x2 - x0);

  ctx.strokeStyle = controls.tangentColor.value;
  ctx.lineWidth = 2.8;
  ctx.beginPath();
  ctx.moveTo(toPxX(x1), toPxY(y1));
  ctx.lineTo(toPxX(x2), toPxY(y2));
  ctx.stroke();

  ctx.fillStyle = "#111111";
  ctx.beginPath();
  ctx.arc(toPxX(x0), toPxY(y0), 6, 0, Math.PI * 2);
  ctx.fill();
}

function drawIntegral(a, b, n) {
  const mode = activeIntegralMode();
  if (mode === "left") drawRectangles("left", a, b, n);
  if (mode === "right") drawRectangles("right", a, b, n);
  if (mode === "both") {
    drawRectangles("right", a, b, n);
    drawRectangles("left", a, b, n);
  }
  if (mode === "trapezoid") drawTrapezoids(a, b, n);
}

function drawRectangles(method, a, b, n) {
  const dx = (b - a) / n;
  const isLeft = method === "left";
  const areaColor = hexToRgb(controls.areaColor.value);
  ctx.fillStyle = isLeft ? rgba(areaColor, 0.24) : "rgba(249, 115, 22, 0.24)";
  ctx.strokeStyle = isLeft ? rgba(areaColor, 0.78) : "rgba(249, 115, 22, 0.78)";
  ctx.lineWidth = 1;

  for (let i = 0; i < n; i += 1) {
    const x = a + i * dx;
    const sampleX = isLeft ? x : x + dx;
    const height = activeFn(sampleX);
    if (!Number.isFinite(height)) continue;
    const px = toPxX(x);
    const py0 = toPxY(0);
    const py = toPxY(height);
    const rectWidth = Math.max(toPxX(x + dx) - px, 1);
    const rectTop = Math.min(py, py0);
    const rectHeight = Math.abs(py0 - py);
    ctx.fillRect(px, rectTop, rectWidth, rectHeight);
    ctx.strokeRect(px, rectTop, rectWidth, rectHeight);
  }
}

function drawTrapezoids(a, b, n) {
  const dx = (b - a) / n;
  const areaColor = hexToRgb(controls.areaColor.value);
  ctx.fillStyle = rgba(areaColor, 0.27);
  ctx.strokeStyle = rgba(areaColor, 0.82);
  ctx.lineWidth = 1.2;

  for (let i = 0; i < n; i += 1) {
    const x1 = a + i * dx;
    const x2 = x1 + dx;
    const y1 = activeFn(x1);
    const y2 = activeFn(x2);
    if (!Number.isFinite(y1) || !Number.isFinite(y2)) continue;
    ctx.beginPath();
    ctx.moveTo(toPxX(x1), toPxY(0));
    ctx.lineTo(toPxX(x1), toPxY(y1));
    ctx.lineTo(toPxX(x2), toPxY(y2));
    ctx.lineTo(toPxX(x2), toPxY(0));
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
}

function drawBounds(a, b) {
  ctx.strokeStyle = "rgba(17, 24, 39, 0.45)";
  ctx.lineWidth = 1.5;
  ctx.setLineDash([5, 6]);
  [a, b].forEach((x) => {
    ctx.beginPath();
    ctx.moveTo(toPxX(x), 0);
    ctx.lineTo(toPxX(x), plotHeight());
    ctx.stroke();
  });
  ctx.setLineDash([]);
}

function drawLabels() {
  ctx.fillStyle = "#6b7280";
  ctx.font = "12px Inter, system-ui, sans-serif";
  ctx.fillText("x", plotWidth() - 18, toPxY(0) - 8);
  ctx.fillText("y", toPxX(0) + 8, 18);
}

function updateReadouts() {
  const { a, b } = getBounds();
  const x0 = Number(controls.pointX.value);
  const n = Number(controls.rectangles.value);
  const mode = activeIntegralMode();
  const fx = activeFn(x0);
  const slope = derivativeAt(x0);
  const area = mode === "both"
    ? `${format(sumValue("left", a, b, n))} / ${format(sumValue("right", a, b, n))}`
    : format(sumValue(mode, a, b, n));

  updateZoomOutput();
  outputs.boundAValue.value = a.toFixed(1);
  outputs.boundBValue.value = b.toFixed(1);
  controls.boundANumber.value = a.toFixed(1);
  controls.boundBNumber.value = b.toFixed(1);
  outputs.pointValue.value = x0.toFixed(2);
  controls.pointXNumber.value = x0.toFixed(2);
  outputs.rectOutput.value = String(n);
  outputs.fxValue.textContent = format(fx);
  outputs.slopeValue.textContent = format(slope);
  outputs.areaValue.textContent = area;
  outputs.readout.textContent = `f(x) = ${state.expression}`;
}

function format(value) {
  if (!Number.isFinite(value)) return "undefined";
  return value.toLocaleString(undefined, {
    minimumFractionDigits: 5,
    maximumFractionDigits: 5,
  });
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function getBounds() {
  const first = Number(controls.boundA.value);
  const second = Number(controls.boundB.value);
  return {
    a: Math.min(first, second),
    b: Math.max(first, second),
  };
}

function resetViewToBounds(a, b) {
  const intervalWidth = Math.max(b - a, 1);
  const zoomFactor = Number(controls.zoomRange.value);
  state.viewCenter = (a + b) / 2;
  state.viewHalfWidth = clamp((intervalWidth / 2) * zoomFactor, 0.5, (GRAPH_MAX - GRAPH_MIN) / 2);
  clampViewToGraphRange();
  state.manualYView = false;
  updateZoomOutput();
}

function clampViewToGraphRange() {
  const maxHalfWidth = (GRAPH_MAX - GRAPH_MIN) / 2;
  state.viewHalfWidth = clamp(state.viewHalfWidth, 0.5, maxHalfWidth);
  if (state.viewHalfWidth >= maxHalfWidth) {
    state.viewCenter = 0;
    return;
  }
  state.viewCenter = clamp(state.viewCenter, GRAPH_MIN + state.viewHalfWidth, GRAPH_MAX - state.viewHalfWidth);
}

function updateZoomOutput() {
  outputs.zoomValue.value = `±${formatTick(state.viewHalfWidth)}`;
}

function activeDerivativeMode() {
  return controls.derivativeMode.value;
}

function activeIntegralMode() {
  return controls.integralMode.value;
}

function hexToRgb(hex) {
  const clean = hex.replace("#", "");
  return {
    r: parseInt(clean.slice(0, 2), 16),
    g: parseInt(clean.slice(2, 4), 16),
    b: parseInt(clean.slice(4, 6), 16),
  };
}

function rgba(color, alpha) {
  return `rgba(${color.r}, ${color.g}, ${color.b}, ${alpha})`;
}

function setTab(mode) {
  controls.viewMode.value = mode;
  tabs.forEach((tab) => tab.classList.toggle("is-active", tab.dataset.tab === mode));
  modePanels.forEach((panel) => {
    panel.hidden = !panel.classList.contains(`${mode}-controls`);
  });
  derivativeFields.forEach((field) => {
    field.hidden = mode === "integral";
  });
  integralFields.forEach((field) => {
    field.hidden = mode === "derivative";
  });

  controls.derivativeMode.value = "tangent";
  controls.integralMode.value = "left";
  controls.zoomRange.value = "1.4";
  controls.boundA.value = "-5";
  controls.boundB.value = "5";
  controls.boundANumber.value = "-5";
  controls.boundBNumber.value = "5";
  controls.pointX.value = "0";
  controls.pointXNumber.value = "0";
  controls.rectangles.value = "12";
  state.lastBoundsKey = "";
  state.manualYView = false;
  draw();
}

tabs.forEach((tab) => {
  tab.addEventListener("click", () => setTab(tab.dataset.tab));
});

Object.values(controls).forEach((control) => {
  if (!control || !control.addEventListener) return;
  if ([controls.boundANumber, controls.boundBNumber, controls.pointXNumber, controls.resetBounds, controls.zoomIn, controls.zoomOut, controls.zoomReset].includes(control)) {
    return;
  }
  control.addEventListener("input", draw);
  control.addEventListener("change", draw);
});

controls.boundANumber.addEventListener("input", () => setBoundFromNumber("a"));
controls.boundBNumber.addEventListener("input", () => setBoundFromNumber("b"));
controls.boundANumber.addEventListener("change", () => setBoundFromNumber("a"));
controls.boundBNumber.addEventListener("change", () => setBoundFromNumber("b"));
controls.pointXNumber.addEventListener("input", setPointFromNumber);
controls.pointXNumber.addEventListener("change", setPointFromNumber);
controls.resetBounds.addEventListener("click", () => {
  controls.boundA.value = "-5";
  controls.boundB.value = "5";
  controls.boundANumber.value = "-5";
  controls.boundBNumber.value = "5";
  controls.pointX.value = "0";
  controls.pointXNumber.value = "0";
  controls.zoomRange.value = "1.4";
  state.lastBoundsKey = "";
  state.manualYView = false;
  draw();
});

function setBoundFromNumber(which) {
  const numberInput = which === "a" ? controls.boundANumber : controls.boundBNumber;
  const slider = which === "a" ? controls.boundA : controls.boundB;
  if (numberInput.value === "") return;
  const value = clamp(Number(numberInput.value), GRAPH_MIN, GRAPH_MAX);
  if (!Number.isFinite(value)) return;
  slider.value = String(value);
  numberInput.value = String(value);
  draw();
}

function setPointFromNumber() {
  if (controls.pointXNumber.value === "") return;
  const { a, b } = getBounds();
  const value = clamp(Number(controls.pointXNumber.value), a, b);
  if (!Number.isFinite(value)) return;
  controls.pointX.value = String(value);
  controls.pointXNumber.value = String(value);
  draw();
}

controls.zoomIn.addEventListener("click", () => changeZoom(-1));
controls.zoomOut.addEventListener("click", () => changeZoom(1));
controls.zoomReset.addEventListener("click", () => {
  const { a, b } = getBounds();
  controls.zoomRange.value = "1.4";
  resetViewToBounds(a, b);
  draw();
});

canvas.addEventListener("pointerdown", (event) => {
  canvas.setPointerCapture(event.pointerId);
  const rect = canvas.getBoundingClientRect();
  const x0 = Number(controls.pointX.value);
  const y0 = activeFn(x0);
  const pointPx = toPxX(x0);
  const pointPy = toPxY(y0);
  const cursorX = event.clientX - rect.left;
  const cursorY = event.clientY - rect.top;
  const nearPoint = controls.viewMode.value === "derivative" && Math.hypot(cursorX - pointPx, cursorY - pointPy) < 18;

  if (nearPoint) {
    state.isPanning = false;
    movePoint(event);
    return;
  }

  state.isPanning = true;
  state.panStartX = cursorX;
  state.panStartY = cursorY;
  state.panStartCenter = state.viewCenter;
  state.panStartYCenter = (state.yMin + state.yMax) / 2;
});

canvas.addEventListener("pointermove", (event) => {
  if (event.buttons !== 1) return;
  const rect = canvas.getBoundingClientRect();
  const cursorX = event.clientX - rect.left;
  const cursorY = event.clientY - rect.top;

  if (state.isPanning) {
    panGraph(cursorX, cursorY);
  } else {
    movePoint(event);
  }
});

canvas.addEventListener("pointerup", () => {
  state.isPanning = false;
});

canvas.addEventListener("pointercancel", () => {
  state.isPanning = false;
});

canvas.addEventListener("wheel", (event) => {
  event.preventDefault();
  const rect = canvas.getBoundingClientRect();
  const anchorX = toMathX(event.clientX - rect.left);
  const anchorY = toMathY(event.clientY - rect.top);
  zoomAt(anchorX, event.deltaY > 0 ? 1.15 : 0.87, anchorY);
});

function changeZoom(delta) {
  const factor = delta > 0 ? 1.22 : 0.82;
  zoomAt(state.viewCenter, factor, (state.yMin + state.yMax) / 2);
}

function panGraph(cursorX, cursorY) {
  const dxPixels = cursorX - state.panStartX;
  const dyPixels = cursorY - state.panStartY;
  const xUnitsPerPixel = (state.xMax - state.xMin) / plotWidth();
  const yUnitsPerPixel = (state.yMax - state.yMin) / plotHeight();
  state.viewCenter = state.panStartCenter - dxPixels * xUnitsPerPixel;
  const yHalfHeight = (state.yMax - state.yMin) / 2;
  const yCenter = state.panStartYCenter + dyPixels * yUnitsPerPixel;
  clampViewToGraphRange();
  state.yMin = yCenter - yHalfHeight;
  state.yMax = yCenter + yHalfHeight;
  state.manualYView = true;
  draw();
}

function zoomAt(anchorX, factor, anchorY) {
  const minHalfWidth = 0.5;
  const maxHalfWidth = (GRAPH_MAX - GRAPH_MIN) / 2;
  const nextHalfWidth = clamp(state.viewHalfWidth * factor, minHalfWidth, maxHalfWidth);
  const ratio = (anchorX - state.xMin) / (state.xMax - state.xMin);
  const nextMin = anchorX - ratio * nextHalfWidth * 2;

  state.viewHalfWidth = nextHalfWidth;
  state.viewCenter = nextMin + nextHalfWidth;
  clampViewToGraphRange();
  state.manualYView = false;
  updateZoomOutput();
  draw();
}

function movePoint(event) {
  const rect = canvas.getBoundingClientRect();
  const { a, b } = getBounds();
  controls.pointX.value = clamp(toMathX(event.clientX - rect.left), a, b).toFixed(2);
  draw();
}

window.addEventListener("resize", resizeCanvas);
resizeCanvas();

function formatTick(value) {
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}
